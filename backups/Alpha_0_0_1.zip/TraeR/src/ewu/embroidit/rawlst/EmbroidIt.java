package ewu.embroidit.rawlst;

public class EmbroidIt
{
    
    public static void main (String[] args)
    {
        EmbroidItGUI gui = new EmbroidItGUI();
        gui.openGUI(args);
    }
}